bl_info = {
    "name" : "Drag & Drop fbx",
    "author" : "DanGry",
    "version": (1, 0, 0),
    "blender" : (4, 1, 0),
    "category": "3D View",
}

import bpy

class AddonPreferences(bpy.types.AddonPreferences):
    bl_idname = __name__

    auto_import: bpy.props.BoolProperty(name="Auto Import", default=True, description="If false, it will show the import options")#type:ignore

    def draw(self, context):
        layout = self.layout
        layout.prop(self, "auto_import", text="Auto Import")

class WM_FH_drag_and_drop_fbx(bpy.types.FileHandler):
    bl_idname = "WM_FH_drag_and_drop_fbx"
    bl_label = "Import FBX"
    bl_import_operator = "wm.import_fbx"
    bl_file_extensions = ".fbx"

    @classmethod
    def poll_drop(cls, context):
        if context.space_data.type == "VIEW_3D":
            return True

class Import_FBX(bpy.types.Operator):
    bl_idname = "wm.import_fbx"
    bl_label = "Import FBX"
    bl_description = "Install Addon"
    bl_options = {'INTERNAL'}

    filepath: bpy.props.StringProperty(subtype="FILE_PATH")#type:ignore

    def execute(self, context):
        if bpy.context.preferences.addons[__name__].preferences.auto_import:
            bpy.ops.import_scene.fbx("EXEC_DEFAULT", filepath=self.filepath)
        else:
            bpy.ops.import_scene.fbx("INVOKE_DEFAULT", filepath=self.filepath)
        return {'FINISHED'}


def register():
    bpy.utils.register_class(AddonPreferences)
    bpy.utils.register_class(WM_FH_drag_and_drop_fbx)
    bpy.utils.register_class(Import_FBX)

def unregister():
    bpy.utils.unregister_class(AddonPreferences)
    bpy.utils.unregister_class(WM_FH_drag_and_drop_fbx)
    bpy.utils.unregister_class(Import_FBX)
